Music in the template is by Mr Smith, and licensed under Creative Commons
Attribution 4.0 International (CC BY 4.0).

https://freemusicarchive.org/music/mr-smith

Mr Smith's music is used in this template project with his explicit permission.
